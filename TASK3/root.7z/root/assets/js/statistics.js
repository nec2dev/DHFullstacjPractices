var ids = [{
    "id": "D",
    "party": "Democrat",
    "idReps": "numDems",
    "idAtt": "attDems",
    "idLoyal": "votDems"
 }, {
    "id": "R",
    "party": "Republican",
    "idReps": "numReps",
    "idAtt": "attReps",
    "idLoyal": "votReps"
 }, {
    "id": "I",
    "party": "Independent",
    "idReps": "numIdeps",
    "idAtt": "attIdeps",
    "idLoyal": "votIdeps"
 }];



